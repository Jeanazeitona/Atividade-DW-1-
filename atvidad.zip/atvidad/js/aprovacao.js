function verificarAprovacao() {
    let media = Number(document.getElementById("media").value);

    if (media >= 6) {
        document.getElementById("resultado").innerHTML = "APROVADO!";
    } else {
        document.getElementById("resultado").innerHTML = "REPROVADO!";
    }
}