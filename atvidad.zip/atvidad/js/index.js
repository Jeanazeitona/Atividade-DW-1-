function calcularMedia() {
    let n1 = Number(document.getElementById("n1").value);
    let n2 = Number(document.getElementById("n2").value);
    let n3 = Number(document.getElementById("n3").value);
    let n4 = Number(document.getElementById("n4").value);
    let n5 = Number(document.getElementById("n5").value);

    let media = (n1 + n2 + n3 + n4 + n5) / 5;

    document.getElementById("resultado").innerHTML = 
        "Sua média é: " + media.toFixed(2);
}